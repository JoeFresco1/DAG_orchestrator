import { readExecutionsV1, recoverRunV1, runTasksV1, stopRunV1 } from './run.js';
import { scheduleTasksV1 } from './scheduler.js';
import type {
  NeutralExecutionV1,
  NeutralRunOptionsV1,
  NeutralRunSummaryV1,
  NeutralTaskV1,
} from './types.js';

/**
 * Frozen pre-extraction task shape consumed by the original product. This is
 * only a wire/name adapter; all scheduling and process behavior stays in the
 * authoritative neutral package implementation.
 */
export interface LegacyNeutralTaskV1 {
  id: string;
  dependsOn: string[];
  command: string;
  args: string[];
  workingDirectory: string;
  outputDirectory: string;
  timeoutMs: number;
  silenceMs: number;
  env?: Record<string, string>;
}

/** Legacy option labels retained for consumers adopting the local archive. */
export interface LegacyNeutralRunOptionsV1 {
  runId: string;
  runFile: string;
  outputDirectory: string;
  concurrency?: number;
  retries?: number;
  maxAttempts?: number;
  logDirectory?: string;
  executionJournalPath?: string;
}

export function legacyTaskToNeutralV1(task: LegacyNeutralTaskV1): NeutralTaskV1 {
  return {
    id: task.id,
    deps: [...task.dependsOn],
    executable: task.command,
    args: [...task.args],
    cwd: task.workingDirectory,
    outputRoot: task.outputDirectory,
    timeoutMs: task.timeoutMs,
    silenceMs: task.silenceMs,
    ...(task.env === undefined ? {} : { env: { ...task.env } }),
  };
}

export function legacyTasksToNeutralV1(tasks: readonly LegacyNeutralTaskV1[]): NeutralTaskV1[] {
  return tasks.map(legacyTaskToNeutralV1);
}

export function scheduleLegacyTasksV1(tasks: readonly LegacyNeutralTaskV1[]): LegacyNeutralTaskV1[] {
  const byId = new Map(tasks.map((task) => [task.id, task]));
  return scheduleTasksV1(legacyTasksToNeutralV1(tasks)).map((task) => {
    const legacyTask = byId.get(task.id);
    if (!legacyTask) throw new Error(`neutral schedule returned unknown task ${task.id}`);
    return legacyTask;
  });
}

function legacyOptionsToNeutralV1(options: LegacyNeutralRunOptionsV1): NeutralRunOptionsV1 {
  return {
    runId: options.runId,
    runFile: options.runFile,
    artifactRoot: options.outputDirectory,
    ...(options.concurrency === undefined ? {} : { concurrency: options.concurrency }),
    ...(options.retries === undefined ? {} : { retries: options.retries }),
    ...(options.maxAttempts === undefined ? {} : { maxAttempts: options.maxAttempts }),
    ...(options.logDirectory === undefined ? {} : { logRoot: options.logDirectory }),
    ...(options.executionJournalPath === undefined
      ? {}
      : { executionStorePath: options.executionJournalPath }),
  };
}

/** Run a legacy-shaped graph through the same neutral scheduler and executor. */
export function runLegacyTasksV1(
  tasks: readonly LegacyNeutralTaskV1[],
  options: LegacyNeutralRunOptionsV1,
): Promise<NeutralRunSummaryV1> {
  return runTasksV1(legacyTasksToNeutralV1(tasks), legacyOptionsToNeutralV1(options));
}

export function readLegacyExecutionsV1(
  runFile: string,
  executionJournalPath?: string,
): Promise<NeutralExecutionV1[]> {
  return readExecutionsV1(runFile, executionJournalPath);
}

export function stopLegacyRunV1(runId: string): Promise<boolean> {
  return stopRunV1(runId);
}

export function recoverLegacyRunV1(
  runFile: string,
  executionJournalPath?: string,
): Promise<NeutralExecutionV1[]> {
  return recoverRunV1(runFile, executionJournalPath);
}
