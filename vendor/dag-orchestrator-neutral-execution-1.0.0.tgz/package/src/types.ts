/**
 * Neutral execution wire types (schema version 1).
 *
 * These describe process-execution facts only: scheduling, spawning, logging,
 * timing, locking and artifact paths. They never carry analytical meaning, a
 * check outcome, or a claim state. Analytics callers interpret an execution
 * separately under their own authority.
 */

export type NeutralProcessStatusV1 = 'running' | 'exited' | 'failed' | 'interrupted';

export type NeutralFailureKindV1 =
  | 'exit'
  | 'spawn'
  | 'timeout'
  | 'stalled'
  | 'killed'
  | 'interrupted';

/** One argv-only process task in a neutral dependency graph. */
export interface NeutralTaskV1 {
  id: string;
  /** Task IDs that must finish successfully before this task is eligible. */
  deps: string[];
  /** Executable name or absolute path. Never a shell string. */
  executable: string;
  /** Argument vector delivered verbatim to the executable. */
  args: string[];
  /** Absolute working directory for the process. */
  cwd: string;
  /** Absolute root the task may write under; must be beneath artifactRoot. */
  outputRoot: string;
  /** Hard process timeout in milliseconds; 0 disables the timeout. */
  timeoutMs: number;
  /** Stall timeout in milliseconds; 0 disables the silence watchdog. */
  silenceMs: number;
  /** Environment overrides merged over the inherited process environment. */
  env?: Record<string, string>;
}

/**
 * Run identity and generic engine controls.
 *
 * `retries`, `maxAttempts`, `reviewRounds`, `repairRounds`, `fallbackChain`
 * and `finalReview` are retained so a shared caller can express the frozen
 * neutral envelope. This package performs process attempts only; it does not
 * implement software review, repair, or harness fallback. Analytics callers
 * set retries 0 / maxAttempts 1 / review rounds 0 / repair rounds 0 / empty
 * fallback / final review off.
 */
export interface NeutralRunOptionsV1 {
  runId: string;
  runFile: string;
  artifactRoot: string;
  concurrency?: number;
  retries?: number;
  maxAttempts?: number;
  reviewRounds?: number;
  repairRounds?: number;
  fallbackChain?: string[];
  finalReview?: 'off' | 'per-task' | 'run';
  logRoot?: string;
  executionStorePath?: string;
}

/** One durable process attempt record. Execution metadata only. */
export interface NeutralExecutionV1 {
  schemaVersion: 1;
  executionId: string;
  runId: string;
  taskId: string;
  attemptId: string;
  processId: number | null;
  startedAt: string;
  endedAt: string | null;
  processStatus: NeutralProcessStatusV1;
  failureKind: NeutralFailureKindV1 | null;
  exitCode: number | null;
  invocationDigest: `sha256:${string}`;
  stdoutLogRef: string;
  stderrLogRef: string;
  producedPaths: string[];
}

export interface NeutralRunSummaryV1 {
  runId: string;
  executions: NeutralExecutionV1[];
  stopped: boolean;
}
