import { createHash } from 'node:crypto';
import { appendFileSync, existsSync, lstatSync, mkdirSync, readdirSync } from 'node:fs';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { setTimeout as sleepTimer, clearTimeout } from 'node:timers';
import type { ChildProcess } from 'node:child_process';
import { killProcessIdV1, killProcessTreeV1, spawnProcessV1 } from './process.js';
import { scheduleTasksV1 } from './scheduler.js';
import { acquireRunLockV1, appendJournalV1, executionStorePathV1, newExecutionIdV1, readJournalV1 } from './storage.js';
import type {
  NeutralExecutionV1,
  NeutralFailureKindV1,
  NeutralRunOptionsV1,
  NeutralRunSummaryV1,
  NeutralTaskV1,
} from './types.js';

interface ActiveProcess {
  child: ChildProcess;
  abort: (kind: NeutralFailureKindV1) => void;
}

interface ActiveRun {
  stop: () => void;
  done: Promise<NeutralRunSummaryV1>;
}

interface AttemptResult {
  exitCode: number | null;
  failureKind: NeutralFailureKindV1 | null;
  processId: number | null;
}

const activeRuns = new Map<string, ActiveRun>();

function safeInteger(name: string, value: number, min: number, max: number): void {
  if (!Number.isSafeInteger(value) || value < min || value > max) {
    throw new Error(`${name} must be an integer between ${min} and ${max}`);
  }
}

function assertTask(task: NeutralTaskV1, artifactRoot: string): void {
  if (!task.id.trim()) throw new Error('task id is empty');
  if (!task.executable.trim()) throw new Error(`task ${task.id} executable is empty`);
  if (!Array.isArray(task.args) || task.args.some((arg) => typeof arg !== 'string')) {
    throw new Error(`task ${task.id} args must be a string array`);
  }
  if (!isAbsolute(task.cwd) || !isAbsolute(task.outputRoot)) {
    throw new Error(`task ${task.id} cwd and outputRoot must be absolute paths`);
  }
  const root = resolve(artifactRoot);
  const output = resolve(task.outputRoot);
  if (output !== root && !output.startsWith(`${root}${sep}`)) {
    throw new Error(`task ${task.id} outputRoot must be beneath artifactRoot`);
  }
  safeInteger(`task ${task.id} timeoutMs`, task.timeoutMs, 0, 24 * 60 * 60 * 1000);
  safeInteger(`task ${task.id} silenceMs`, task.silenceMs, 0, 24 * 60 * 60 * 1000);
}

function sha256(value: unknown): `sha256:${string}` {
  return `sha256:${createHash('sha256').update(JSON.stringify(value)).digest('hex')}`;
}

function snapshotFiles(root: string): Set<string> {
  const files = new Set<string>();
  if (!existsSync(root)) return files;
  const visit = (dir: string): void => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      const stat = lstatSync(path);
      if (stat.isSymbolicLink()) continue;
      if (stat.isDirectory()) visit(path);
      else if (stat.isFile()) files.add(resolve(path));
    }
  };
  visit(root);
  return files;
}

function producedPaths(root: string, before: Set<string>): string[] {
  return [...snapshotFiles(root)]
    .filter((path) => !before.has(path))
    .map((path) => relative(root, path).split(sep).join('/'))
    .sort();
}

function readLatestExecutions(path: string): Map<string, NeutralExecutionV1> {
  const executions = new Map<string, NeutralExecutionV1>();
  for (const event of readJournalV1(path)) executions.set(event.execution.executionId, event.execution);
  return executions;
}

function runAttempt(
  task: NeutralTaskV1,
  attemptNumber: number,
  logRoot: string,
  onStart: (process: ActiveProcess) => void,
  onSettled: (process: ActiveProcess) => void,
  isStopped: () => boolean,
  setPid: (processId: number | null) => void,
): Promise<AttemptResult> {
  return new Promise((resolveAttempt) => {
    const stdoutLogRef = join(logRoot, task.id, `attempt-${attemptNumber}.stdout.log`);
    const stderrLogRef = join(logRoot, task.id, `attempt-${attemptNumber}.stderr.log`);
    mkdirSync(dirname(stdoutLogRef), { recursive: true });
    appendFileSync(stdoutLogRef, '', 'utf8');
    appendFileSync(stderrLogRef, '', 'utf8');
    let failureKind: NeutralFailureKindV1 | null = isStopped() ? 'interrupted' : null;
    let settled = false;
    let timeout: NodeJS.Timeout | undefined;
    let silence: NodeJS.Timeout | undefined;
    let active: ActiveProcess | null = null;
    const settle = (result: AttemptResult): void => {
      if (settled) return;
      settled = true;
      if (timeout) clearTimeout(timeout);
      if (silence) clearTimeout(silence);
      if (active) onSettled(active);
      resolveAttempt(result);
    };
    const setFailureTimer = (kind: 'timeout' | 'stalled', ms: number): NodeJS.Timeout | undefined =>
      ms > 0
        ? sleepTimer(() => {
            failureKind = kind;
            if (active) active.abort(kind);
          }, ms)
        : undefined;
    const onChunk = (channel: 'stdout' | 'stderr', chunk: Buffer | string): void => {
      const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      appendFileSync(channel === 'stdout' ? stdoutLogRef : stderrLogRef, data);
      if (task.silenceMs > 0) {
        if (silence) clearTimeout(silence);
        silence = setFailureTimer('stalled', task.silenceMs);
      }
    };

    let child: ChildProcess;
    try {
      child = spawnProcessV1(task.executable, task.args, {
        cwd: task.cwd,
        env: { ...process.env, ...(task.env ?? {}) },
        windowsHide: true,
        detached: process.platform !== 'win32',
        stdio: ['ignore', 'pipe', 'pipe'],
      });
    } catch {
      settle({ exitCode: null, failureKind: 'spawn', processId: null });
      return;
    }
    setPid(child.pid ?? null);
    active = {
      child,
      abort: (kind) => {
        if (settled) return;
        failureKind = kind;
        killProcessTreeV1(child);
      },
    };
    onStart(active);
    child.stdout?.on('data', (chunk: Buffer) => onChunk('stdout', chunk));
    child.stderr?.on('data', (chunk: Buffer) => onChunk('stderr', chunk));
    child.on('error', () => {
      setPid(null);
      settle({ exitCode: null, failureKind: 'spawn', processId: child.pid ?? null });
    });
    child.on('close', (code, signal) => {
      setPid(null);
      if (isStopped() && failureKind === null) failureKind = 'interrupted';
      if (failureKind === null && (signal || code === null)) failureKind = 'killed';
      if (failureKind === null && code !== 0) failureKind = 'exit';
      settle({ exitCode: code, failureKind, processId: child.pid ?? null });
    });
    timeout = setFailureTimer('timeout', task.timeoutMs);
    if (task.silenceMs > 0) silence = setFailureTimer('stalled', task.silenceMs);
    if (isStopped()) active.abort('interrupted');
  });
}

/**
 * Run a neutral dependency graph using argv-only child processes under one run
 * lock. Each task is attempted up to `maxAttempts` times. Process facts are
 * journaled and returned; no analytical interpretation is applied.
 */
export async function runTasksV1(
  tasks: readonly NeutralTaskV1[],
  options: NeutralRunOptionsV1,
): Promise<NeutralRunSummaryV1> {
  if (!options.runId.trim()) throw new Error('runId is required');
  if (!options.runFile.trim() || !options.artifactRoot.trim()) {
    throw new Error('runFile and artifactRoot are required');
  }
  const ordered = scheduleTasksV1(tasks);
  const concurrency = options.concurrency ?? 1;
  const retries = options.retries ?? 0;
  const maxAttempts = options.maxAttempts ?? retries + 1;
  safeInteger('concurrency', concurrency, 1, 64);
  safeInteger('retries', retries, 0, 100);
  safeInteger('maxAttempts', maxAttempts, 1, 101);
  if (maxAttempts > retries + 1) throw new Error('maxAttempts cannot exceed retries + 1');
  safeInteger('reviewRounds', options.reviewRounds ?? 0, 0, 100);
  safeInteger('repairRounds', options.repairRounds ?? 0, 0, 100);
  const root = resolve(options.artifactRoot);
  const store = executionStorePathV1(options.runFile, options.executionStorePath);
  const logRoot = resolve(options.logRoot ?? join(root, '.neutral-execution', 'logs', options.runId));
  mkdirSync(root, { recursive: true });
  mkdirSync(logRoot, { recursive: true });
  for (const task of ordered) assertTask(task, root);
  const release = acquireRunLockV1(options.runFile, options.runId);
  const executions: NeutralExecutionV1[] = [];
  const statuses = new Map<string, 'pending' | 'running' | 'finished' | 'failed' | 'skipped'>(
    ordered.map((task) => [task.id, 'pending']),
  );
  const running = new Map<string, Promise<void>>();
  const processes = new Set<ActiveProcess>();
  let stopped = false;
  let resolveDone: (summary: NeutralRunSummaryV1) => void = () => undefined;
  const done = new Promise<NeutralRunSummaryV1>((resolve) => {
    resolveDone = resolve;
  });
  const stop = (): void => {
    stopped = true;
    for (const active of processes) active.abort('interrupted');
  };
  activeRuns.set(options.runId, { stop, done });

  const execute = async (task: NeutralTaskV1): Promise<void> => {
    statuses.set(task.id, 'running');
    let finalFailure = true;
    for (let attempt = 1; attempt <= maxAttempts && !stopped; attempt++) {
      const executionId = newExecutionIdV1();
      const startedAt = new Date().toISOString();
      const digest = sha256({ executable: task.executable, args: task.args, cwd: task.cwd, env: task.env ?? {} });
      const entry: NeutralExecutionV1 = {
        schemaVersion: 1,
        executionId,
        runId: options.runId,
        taskId: task.id,
        attemptId: `${options.runId}:${task.id}:${attempt}`,
        processId: null,
        startedAt,
        endedAt: null,
        processStatus: 'running',
        failureKind: null,
        exitCode: null,
        invocationDigest: digest,
        stdoutLogRef: relative(dirname(store), join(logRoot, task.id, `attempt-${attempt}.stdout.log`))
          .split(sep)
          .join('/'),
        stderrLogRef: relative(dirname(store), join(logRoot, task.id, `attempt-${attempt}.stderr.log`))
          .split(sep)
          .join('/'),
        producedPaths: [],
      };
      appendJournalV1(store, { kind: 'started', execution: entry });
      const before = snapshotFiles(task.outputRoot);
      const processResult = await runAttempt(
        task,
        attempt,
        logRoot,
        (active) => processes.add(active),
        (active) => processes.delete(active),
        () => stopped,
        (pid) => {
          entry.processId = pid;
        },
      );
      entry.endedAt = new Date().toISOString();
      entry.exitCode = processResult.exitCode;
      entry.failureKind = processResult.failureKind;
      entry.processStatus =
        processResult.failureKind === 'interrupted'
          ? 'interrupted'
          : processResult.failureKind === null
            ? 'exited'
            : 'failed';
      entry.producedPaths = producedPaths(task.outputRoot, before);
      appendJournalV1(store, { kind: 'finished', execution: entry });
      executions.push(entry);
      if (processResult.failureKind === null) {
        finalFailure = false;
        break;
      }
      if (processResult.failureKind === 'interrupted') break;
    }
    statuses.set(task.id, finalFailure ? 'failed' : 'finished');
  };

  try {
    while (!stopped) {
      let launched = false;
      for (const task of ordered) {
        if (running.size >= concurrency) break;
        if (statuses.get(task.id) !== 'pending') continue;
        const deps = task.deps.map((id) => statuses.get(id));
        if (deps.some((status) => status === 'failed' || status === 'skipped')) {
          statuses.set(task.id, 'skipped');
          continue;
        }
        if (deps.some((status) => status !== 'finished')) continue;
        launched = true;
        const promise = execute(task).finally(() => running.delete(task.id));
        running.set(task.id, promise);
      }
      if (running.size > 0) {
        await Promise.race(running.values());
        continue;
      }
      if (
        !launched ||
        [...statuses.values()].every((status) => status === 'finished' || status === 'failed' || status === 'skipped')
      ) {
        break;
      }
    }
    if (stopped && running.size > 0) await Promise.all(running.values());
    const summary: NeutralRunSummaryV1 = { runId: options.runId, executions, stopped };
    resolveDone(summary);
    return summary;
  } finally {
    activeRuns.delete(options.runId);
    release();
  }
}

/** Stop a currently active neutral run. It never retries or resubmits work. */
export async function stopRunV1(runId: string): Promise<boolean> {
  const active = activeRuns.get(runId);
  if (!active) return false;
  active.stop();
  await active.done;
  return true;
}

/** Read the latest durable process record for every execution attempt. */
export async function readExecutionsV1(runFile: string, executionStore?: string): Promise<NeutralExecutionV1[]> {
  const store = executionStorePathV1(runFile, executionStore);
  return [...readLatestExecutions(store).values()].sort((a, b) => a.startedAt.localeCompare(b.startedAt));
}

/**
 * Close out journaled in-flight processes as interrupted after a crash. It
 * retains the interruption and never resubmits the task.
 */
export async function recoverRunV1(runFile: string, executionStore?: string): Promise<NeutralExecutionV1[]> {
  const store = executionStorePathV1(runFile, executionStore);
  const latest = readLatestExecutions(store);
  const recovered: NeutralExecutionV1[] = [];
  for (const execution of latest.values()) {
    if (execution.processStatus !== 'running') continue;
    if (execution.processId !== null) killProcessIdV1(execution.processId);
    const recoveredExecution: NeutralExecutionV1 = {
      ...execution,
      endedAt: new Date().toISOString(),
      processStatus: 'interrupted',
      failureKind: 'interrupted',
      exitCode: null,
    };
    appendJournalV1(store, { kind: 'finished', execution: recoveredExecution });
    recovered.push(recoveredExecution);
  }
  return recovered;
}
