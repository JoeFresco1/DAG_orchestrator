import { appendFileSync, closeSync, existsSync, mkdirSync, openSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { NeutralExecutionV1 } from './types.js';

/** Append-only journal event for one execution attempt. */
export interface NeutralJournalEventV1 {
  kind: 'started' | 'finished';
  execution: NeutralExecutionV1;
}

/** Resolve the durable execution journal path for a run file. */
export function executionStorePathV1(runFile: string, explicit?: string): string {
  return resolve(explicit ?? `${runFile}.neutral-executions.jsonl`);
}

/**
 * Read the execution journal. A torn final append is ignored; earlier complete
 * events remain authoritative.
 */
export function readJournalV1(path: string): NeutralJournalEventV1[] {
  if (!existsSync(path)) return [];
  const events: NeutralJournalEventV1[] = [];
  const content = readFileSync(path, 'utf8');
  for (const line of content.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const parsed = JSON.parse(line) as NeutralJournalEventV1;
      if ((parsed.kind === 'started' || parsed.kind === 'finished') && parsed.execution?.executionId) {
        events.push(parsed);
      }
    } catch {
      // Ignore an incomplete trailing line.
    }
  }
  return events;
}

export function appendJournalV1(path: string, event: NeutralJournalEventV1): void {
  mkdirSync(dirname(path), { recursive: true });
  appendFileSync(path, `${JSON.stringify(event)}\n`, 'utf8');
}

/**
 * Acquire the per-run neutral lock. The lock is a distinct neutral concern
 * from any analytics controller-ownership lock. Returns a release function.
 */
export function acquireRunLockV1(runFile: string, runId: string): () => void {
  const lockPath = resolve(`${runFile}.neutral.lock`);
  mkdirSync(dirname(lockPath), { recursive: true });
  let fd: number;
  try {
    fd = openSync(lockPath, 'wx');
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    if (code === 'EEXIST') throw new Error(`neutral run is locked: ${lockPath}`);
    throw error;
  }
  writeFileSync(fd, `${JSON.stringify({ runId, pid: process.pid, acquiredAt: new Date().toISOString() })}\n`, 'utf8');
  closeSync(fd);
  let released = false;
  return () => {
    if (released) return;
    released = true;
    try {
      unlinkSync(lockPath);
    } catch {
      // Best effort after the run has already settled.
    }
  };
}

export function newExecutionIdV1(): string {
  return `exec_${randomUUID()}`;
}
