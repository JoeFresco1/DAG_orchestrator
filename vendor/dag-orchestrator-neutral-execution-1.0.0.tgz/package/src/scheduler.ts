import type { NeutralTaskV1 } from './types.js';

/**
 * Validate a neutral task graph and return a deterministic dependency order.
 *
 * Order is breadth-first over declaration order: roots are released in input
 * order and a task is emitted once every dependency has been emitted. Duplicate
 * IDs, unknown dependencies, duplicate dependencies and cycles are rejected.
 */
export function scheduleTasksV1(tasks: readonly NeutralTaskV1[]): NeutralTaskV1[] {
  const byId = new Map<string, NeutralTaskV1>();
  for (const task of tasks) {
    if (!task.id || byId.has(task.id)) throw new Error(`duplicate or empty task id: ${task.id}`);
    byId.set(task.id, task);
  }
  for (const task of tasks) {
    const seen = new Set<string>();
    for (const dep of task.deps) {
      if (dep === task.id) throw new Error(`task ${task.id} depends on itself`);
      if (!byId.has(dep)) throw new Error(`task ${task.id} has unknown dependency ${dep}`);
      if (seen.has(dep)) throw new Error(`task ${task.id} has duplicate dependency ${dep}`);
      seen.add(dep);
    }
  }

  const incoming = new Map(tasks.map((task) => [task.id, task.deps.length]));
  const dependents = new Map<string, string[]>();
  for (const task of tasks) {
    for (const dep of task.deps) {
      const children = dependents.get(dep) ?? [];
      children.push(task.id);
      dependents.set(dep, children);
    }
  }
  const ready = tasks.filter((task) => task.deps.length === 0).map((task) => task.id);
  const ordered: NeutralTaskV1[] = [];
  while (ready.length > 0) {
    const id = ready.shift();
    if (id === undefined) break;
    const task = byId.get(id);
    if (!task) continue;
    ordered.push(task);
    for (const child of dependents.get(id) ?? []) {
      const count = (incoming.get(child) ?? 0) - 1;
      incoming.set(child, count);
      if (count === 0) ready.push(child);
    }
  }
  if (ordered.length !== tasks.length) throw new Error('task dependency graph contains a cycle');
  return ordered;
}
