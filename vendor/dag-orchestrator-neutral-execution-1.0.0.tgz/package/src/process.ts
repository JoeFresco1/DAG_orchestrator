import { spawn, spawnSync, type ChildProcess, type SpawnOptions } from 'node:child_process';

/**
 * Spawn an executable with an argument vector. Shell parsing is never enabled,
 * so task text cannot be reinterpreted as shell syntax.
 */
export function spawnProcessV1(
  executable: string,
  args: readonly string[],
  options: SpawnOptions = {},
): ChildProcess {
  return spawn(executable, [...args], { ...options, shell: false });
}

/**
 * Stop the process tree created by {@link spawnProcessV1}. On Windows a direct
 * kill leaves grandchildren alive, so the whole tree is terminated by pid.
 */
export function killProcessTreeV1(child: ChildProcess): void {
  if (child.pid) {
    if (process.platform === 'win32') {
      const result = spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], {
        windowsHide: true,
        stdio: 'ignore',
      });
      if (result.status === 0) return;
    } else {
      try {
        process.kill(-child.pid, 'SIGKILL');
        return;
      } catch {
        // The process group is gone; fall through to a direct-child kill.
      }
    }
  }
  try {
    child.kill('SIGKILL');
  } catch {
    // The process already exited.
  }
}

/** Stop a recovered process by pid, when no child handle was preserved. */
export function killProcessIdV1(pid: number): void {
  if (!Number.isSafeInteger(pid) || pid <= 0) return;
  if (process.platform === 'win32') {
    // taskkill /T and WMI can be unavailable to an unprivileged local runner.
    // Toolhelp's process snapshot exposes parent PIDs without WMI, allowing
    // recovery to terminate descendants with the same rights as Node's
    // process.kill and then verify the whole discovered tree.
    const script = [
      `Add-Type -TypeDefinition @'`,
      'using System;',
      'using System.Collections.Generic;',
      'using System.Runtime.InteropServices;',
      'public static class NeutralProcessTreeV1 {',
      '  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]',
      '  public struct ProcessEntry {',
      '    public uint size; public uint usage; public uint processId; public IntPtr heap;',
      '    public uint moduleId; public uint threads; public uint parentProcessId;',
      '    public int priority; public uint flags;',
      '    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string name;',
      '  }',
      '  [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint processId);',
      '  [DllImport("kernel32.dll", EntryPoint="Process32FirstW", CharSet=CharSet.Unicode, SetLastError=true)] public static extern bool Process32First(IntPtr snapshot, ref ProcessEntry entry);',
      '  [DllImport("kernel32.dll", EntryPoint="Process32NextW", CharSet=CharSet.Unicode, SetLastError=true)] public static extern bool Process32Next(IntPtr snapshot, ref ProcessEntry entry);',
      '  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr handle);',
      '  public static uint[] ParentPairs() {',
      '    IntPtr snapshot = CreateToolhelp32Snapshot(2, 0);',
      '    if (snapshot == new IntPtr(-1)) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());',
      '    try {',
      '      var entry = new ProcessEntry(); entry.size = (uint)Marshal.SizeOf(typeof(ProcessEntry));',
      '      var pairs = new List<uint>();',
      '      if (Process32First(snapshot, ref entry)) {',
      '        do { pairs.Add(entry.processId); pairs.Add(entry.parentProcessId); entry.size = (uint)Marshal.SizeOf(typeof(ProcessEntry)); }',
      '        while (Process32Next(snapshot, ref entry));',
      '      }',
      '      return pairs.ToArray();',
      '    } finally { CloseHandle(snapshot); }',
      '  }',
      '}',
      "'@",
      `$target = ${pid}`,
      '$pairs = [NeutralProcessTreeV1]::ParentPairs()',
      '$children = @{}',
      'for ($index = 0; $index -lt $pairs.Length; $index += 2) {',
      '  $childPid = [int]$pairs[$index]; $parentPid = [int]$pairs[$index + 1]',
      '  if (-not $children.ContainsKey($parentPid)) { $children[$parentPid] = [System.Collections.Generic.List[int]]::new() }',
      '  $children[$parentPid].Add($childPid)',
      '}',
      '$queue = [System.Collections.Generic.Queue[int]]::new()',
      '$descendants = [System.Collections.Generic.List[int]]::new()',
      '$treeIds = [System.Collections.Generic.HashSet[int]]::new()',
      '$treeIds.Add($target) | Out-Null',
      '$queue.Enqueue($target)',
      'while ($queue.Count -gt 0) {',
      '  $parent = $queue.Dequeue()',
      '  if ($children.ContainsKey($parent)) {',
      '    foreach ($childPid in $children[$parent]) {',
      '      if ($treeIds.Add($childPid)) { $descendants.Add($childPid); $queue.Enqueue($childPid) }',
      '    }',
      '  }',
      '}',
      'for ($index = $descendants.Count - 1; $index -ge 0; $index--) {',
      '  Stop-Process -Id $descendants[$index] -Force -ErrorAction SilentlyContinue',
      '}',
      'Stop-Process -Id $target -Force -ErrorAction SilentlyContinue',
      '$deadline = (Get-Date).AddSeconds(3)',
      'while ($true) {',
      '  $remaining = @()',
      '  foreach ($treePid in $treeIds) {',
      '    try { $candidate = [System.Diagnostics.Process]::GetProcessById($treePid); if (-not $candidate.HasExited) { $remaining += $treePid }; $candidate.Dispose() }',
      '    catch [ArgumentException] { }',
      '  }',
      '  if (-not $remaining) { exit 0 }',
      '  if ((Get-Date) -ge $deadline) { exit 2 }',
      '  Start-Sleep -Milliseconds 50',
      '}',
    ].join('\n');
    const result = spawnSync(
      'powershell.exe',
      ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
      { windowsHide: true, stdio: 'ignore' },
    );
    if (result.status === 0) return;
    throw new Error(
      `could not confirm termination of Windows process tree ${pid} (powershell=${result.status ?? result.error?.message ?? 'unavailable'})`,
    );
  }
  try {
    process.kill(-pid, 'SIGKILL');
  } catch {
    try {
      process.kill(pid, 'SIGKILL');
    } catch {
      // The process already exited.
    }
  }
}
