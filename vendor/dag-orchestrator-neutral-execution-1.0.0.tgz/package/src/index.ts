/**
 * @dag-orchestrator/neutral-execution
 *
 * The single authoritative neutral execution source: argv-only process launch,
 * dependency scheduling, per-attempt logs, timeouts, run locking, artifact
 * roots, stop/cancellation and interrupted/crash recovery.
 *
 * It reports execution metadata only. It never assigns analytical meaning to a
 * process status, and it does not run review, repair or fallback logic.
 */
export type {
  NeutralExecutionV1,
  NeutralFailureKindV1,
  NeutralProcessStatusV1,
  NeutralRunOptionsV1,
  NeutralRunSummaryV1,
  NeutralTaskV1,
} from './types.js';
export { readExecutionsV1, recoverRunV1, runTasksV1, stopRunV1 } from './run.js';
export { scheduleTasksV1 } from './scheduler.js';
export {
  spawnProcessV1,
  killProcessTreeV1,
  killProcessIdV1,
} from './process.js';
export type { NeutralJournalEventV1 } from './storage.js';
export { executionStorePathV1, readJournalV1 } from './storage.js';
export {
  legacyTaskToNeutralV1,
  legacyTasksToNeutralV1,
  scheduleLegacyTasksV1,
  runLegacyTasksV1,
  readLegacyExecutionsV1,
  stopLegacyRunV1,
  recoverLegacyRunV1,
} from './legacy-adapter.js';
export type { LegacyNeutralRunOptionsV1, LegacyNeutralTaskV1 } from './legacy-adapter.js';
